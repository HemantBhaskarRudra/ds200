#!/usr/bin/env python
# coding: utf-8

# In[75]:


import numpy as np
import matplotlib.pyplot as plt
import sys
import csv

# In[76]:

year=[]
anual=[]
total=[]
colorX=[]
dec_feb=[]
mar_may=[]
jun_sep=[]
ocb_nov=[]
jan=[]
feb=[]
mar=[]
apr=[]
may=[]
jun=[]
jul=[]
aug=[]
sep=[]
ocb=[]
nov=[]
dec=[]


for i in range(5):
	points=np.loadtxt(sys.argv[1], delimiter=',', skiprows=1, usecols=(0))
	for each in points:
		year.append(int(each))

#print(year)

count_native_line = 0
with open(sys.argv[1], 'r') as data_csv:	
    read_csv_data = csv.reader(data_csv, delimiter=',')    
    for value in read_csv_data:
        if count_native_line == 0:
            count_native_line += 1
        else:
        	anual.append(float(value[13]))
        	jan.append(float(value[1]))
        	feb.append(float(value[2]))
        	mar.append(float(value[3]))
        	apr.append(float(value[4]))
        	may.append(float(value[5]))
        	jun.append(float(value[6]))
        	jul.append(float(value[7]))
        	aug.append(float(value[8]))
        	sep.append(float(value[9]))
        	ocb.append(float(value[10]))
        	nov.append(float(value[11]))
        	dec.append(float(value[12]))
        	count_native_line += 1


length=len(anual)
#print(length)

for i in range(length):
	dec_feb_average=(dec[i]+jan[i]+feb[i])/3
	mar_may_average=(mar[i]+apr[i]+may[i])/3
	jun_sep_average=(jun[i]+jul[i]+aug[i]+sep[i])/4
	ocb_nov_average=(ocb[i]+nov[i])/2
	dec_feb.append(float('%.2f'%(dec_feb_average)))
	mar_may.append(float('%.2f'%(mar_may_average)))
	jun_sep.append(float('%.2f'%(jun_sep_average)))
	ocb_nov.append(float('%.2f'%(ocb_nov_average)))


for each in dec_feb:
	total.append(float(each))
	colorX.append('silver')
for each in mar_may:
	total.append(float(each))
	colorX.append('lightskyblue')
for each in jun_sep:
	total.append(float(each))
	colorX.append('lightpink')
for each in ocb_nov:
	total.append(float(each))
	colorX.append('lightgreen')
for each in anual:
	total.append(float(each))
	colorX.append('red')


th = np.linspace(0, 2*np.pi, 128)


fig, ax = plt.subplots(figsize=(15,10))

a=[]
b=[]
plt.scatter(year, total, color=colorX)
plt.xticks( fontsize=7, rotation=0)
plt.yticks( fontsize=7 )
plt.xlabel('year', fontsize=10)
plt.ylabel('average maximum temperature', fontsize=10)
plt.title('average maximum temperature of INDIA season-wise and annual per year')
plt.scatter(a,b,label='dec_to_feb (winter)', color='silver')
plt.scatter(a,b,label='mar_to_may (summer)', color='lightskyblue')
plt.scatter(a,b,label='jun_to_sep (monsoon)', color='lightpink')
plt.scatter(a,b,label='oct_to_nov (autumn)', color='lightgreen')
plt.scatter(a,b,label='annual', color='red')
plt.grid(color='silver', linestyle='-', linewidth=0.4)
plt.legend()
plt.show()